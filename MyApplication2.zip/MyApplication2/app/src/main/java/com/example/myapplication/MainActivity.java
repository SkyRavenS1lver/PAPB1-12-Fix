package com.example.myapplication;

import android.support.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    EditText mNameEditText, mAddressEditTest, mUpdateNameEditText, mUpdatedAddressEditText;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNameEditText = findViewById(R.id.etName);
        mAddressEditTest = findViewById(R.id.etAddress);
        mUpdateNameEditText = findViewById(R.id.etUpdateName);
        mUpdatedAddressEditText = findViewById(R.id.etUpdateAddress);
        databaseReference = FirebaseDatabase.getInstance().getReference(Student.class.getSimpleName());

        findViewById(R.id.buttonRead).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        findViewById(R.id.buttonUpdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        findViewById(R.id.buttonInsert).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Student newStudent = new Student();
                String name = mNameEditText.getText().toString();
                String address = mAddressEditTest.getText().toString();
                if (name != "" && address != ""){
                    newStudent.setNama(name);
                    newStudent.setAddress(address);

                    databaseReference.push().setValue(newStudent);
//                    Toast.makeText(this, "Berhasil", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}